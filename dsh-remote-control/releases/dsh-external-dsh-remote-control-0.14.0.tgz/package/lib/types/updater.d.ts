export declare const PACKAGE_NAME = "@dsh-external/dsh-remote-control";
export interface UpdateManifest {
    version: string;
    /** Absolute https URL, or a path relative to the manifest URL. */
    tarball: string;
    sha256: string;
    notes?: string;
    publishedAt?: string;
}
export interface UpdateState {
    /** Whether to check automatically in the background. */
    autoCheck: boolean;
    /** Whether to install a found update without asking (still requires a restart). */
    autoInstall: boolean;
    /** Manifest location; empty means the built-in default. */
    manifestUrl: string;
    /** Hours between automatic checks. */
    intervalHours: number;
    lastCheckAt?: number;
    lastCheckVersion?: string;
    lastError?: string;
    /** Version the user explicitly dismissed, so the UI can stay quiet. */
    skippedVersion?: string;
    /** Version staged and applied, pending restart. */
    pendingRestart?: string;
}
export declare const DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/zhangxuesong-06/dsh-remote-control/main/releases/manifest.json";
interface Semver {
    major: number;
    minor: number;
    patch: number;
    pre: string;
}
export declare function parseSemver(input: string): Semver | null;
/** Returns <0, 0, >0 like a comparator; unparsable versions sort below valid ones. */
export declare function compareSemver(a: string, b: string): number;
export declare function isNewer(candidate: string, current: string): boolean;
export declare function loadUpdateState(path: string): UpdateState;
export declare function saveUpdateState(path: string, state: UpdateState): void;
export declare function isAllowedSource(url: string): boolean;
export declare function validateManifest(raw: unknown, manifestUrl: string): {
    ok: true;
    manifest: UpdateManifest;
} | {
    ok: false;
    error: string;
};
export interface CheckResult {
    ok: boolean;
    current: string;
    latest?: string;
    updateAvailable: boolean;
    manifest?: UpdateManifest;
    error?: string;
    /** Manifest URL actually used (after applying defaults). */
    source?: string;
}
export declare function checkForUpdate(currentVersion: string, manifestUrl?: string, timeoutMs?: number): Promise<CheckResult>;
/**
 * Reject archives that try to escape the extraction directory or smuggle links.
 * `tar -tvzf` prefix: d=dir, -=file, l=symlink, h=hardlink, c=char, b=block, p=fifo.
 */
export declare function inspectArchive(listing: string): {
    ok: true;
} | {
    ok: false;
    error: string;
};
export interface StageResult {
    ok: boolean;
    dir?: string;
    version?: string;
    log: string[];
}
/** Download, hash-check and unpack a manifest's tarball into a fresh staging directory. */
export declare function stageUpdate(manifest: UpdateManifest, workDir: string): Promise<StageResult>;
export interface ApplyResult {
    ok: boolean;
    backup?: string;
    log: string[];
    restartRequired?: boolean;
}
/**
 * Replace the release files in `installDir` with the staged build.
 * The previous release is copied to `backupRoot` first; any failure restores it.
 */
export declare function applyStaged(stagedDir: string, installDir: string, backupRoot: string): ApplyResult;
/** Resolve the plugin's own install root from the compiled module location. */
export declare function installRootFromModule(moduleUrl: string): string;
export {};
