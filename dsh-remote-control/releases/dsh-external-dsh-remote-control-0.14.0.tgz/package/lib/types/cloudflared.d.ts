export declare const CLOUDFLARED_VERSION = "2024.10.0";
export declare function cloudflaredBinDir(baseDir: string): string;
export declare function cloudflaredBinPath(baseDir: string): string;
/** Path to a usable cloudflared: an existing managed copy, else one found on PATH. */
export declare function resolveCloudflared(baseDir: string): Promise<{
    path: string;
    managed: boolean;
} | null>;
/** Download the pinned cloudflared release into the plugin data dir. */
export declare function installCloudflared(baseDir: string): Promise<{
    ok: boolean;
    path?: string;
    log: string[];
}>;
export interface QuickTunnelState {
    running: boolean;
    url?: string;
    port?: number;
    startedAt?: number;
    error?: string;
    log: string[];
}
/**
 * Start a quick tunnel to a local HTTP port and capture the *.trycloudflare.com URL.
 * Keeps the process alive; call stopQuickTunnel to kill it.
 */
export declare class QuickTunnel {
    private binPath;
    private handshakeMs;
    private child;
    state: QuickTunnelState;
    constructor(binPath: string, handshakeMs?: number);
    start(port: number): Promise<QuickTunnelState>;
    stop(): void;
}
