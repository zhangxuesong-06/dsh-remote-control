import type { HealthInfo } from "./agent-http.js";
import type { RemoteMachine } from "./registry.js";
export interface HostStatus {
    checkedAt: number;
    online: boolean;
    text: string;
    health?: HealthInfo;
}
/** Runtime-only observations. Configuration/credentials changing always invalidate a cached result. */
export declare class HostCatalog {
    private observed;
    readonly ttlMs: number;
    /** Resolve the SSH identity file for SSH machines. */
    private identityFile?;
    private cache;
    private pending;
    constructor(observed: (machine: RemoteMachine, health: HealthInfo) => void, ttlMs?: number, 
    /** Resolve the SSH identity file for SSH machines. */
    identityFile?: (() => string) | undefined);
    private key;
    peek(machine: RemoteMachine): HostStatus | undefined;
    forget(id: string): void;
    probe(machine: RemoteMachine, timeoutMs: number, refresh?: boolean): Promise<HostStatus>;
}
