export interface ForwarderState {
    /** Cloudflare hostname being forwarded (e.g. ssh.example.com). */
    hostname: string;
    /** Local port the forwarder listens on. */
    localPort: number;
    running: boolean;
    startedAt?: number;
    restarts: number;
    error?: string;
    log: string[];
}
/** Ask the OS for a free TCP port on the loopback interface. */
export declare function pickFreePort(host?: string): Promise<number>;
/** True when something accepts TCP connections on host:port (the forwarder is ready). */
export declare function canConnect(host: string, port: number, timeoutMs?: number): Promise<boolean>;
export declare class TunnelForwarder {
    private binPath;
    private localPort;
    private readyTimeoutMs;
    state: ForwarderState;
    private child;
    private timer;
    private stopping;
    constructor(binPath: string, hostname: string, localPort: number, readyTimeoutMs?: number);
    /** Start and resolve once the local port accepts connections (or fail with a reason). */
    start(): Promise<ForwarderState>;
    /**
     * Open a TCP connection through the forwarder. If cloudflared cannot reach the configured
     * hostname it closes immediately, and its log names the reason, which we surface verbatim.
     */
    private probeThrough;
    /** Best available reason from cloudflared's own log lines. */
    private failureReason;
    private waitReady;
    /** Restart after an unexpected exit, with a simple linear backoff cap. */
    private onExit;
    private clearTimer;
    private kill;
    stop(): void;
}
