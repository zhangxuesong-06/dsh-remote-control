export interface DiscoveredHost {
    /** Best identifier: the SSH config alias, else the host address. */
    id: string;
    host: string;
    user?: string;
    port?: number;
    /** Where this candidate came from. */
    source: "ssh-config" | "known-hosts";
    /** Alias from ssh config, when present. */
    alias?: string;
    /** Whether a private key likely exists to authenticate (informational). */
    hint?: string;
}
/** Parse ~/.ssh/config into host entries. Handles Host aliases, HostName, User, Port. */
export declare function parseSshConfig(text: string): DiscoveredHost[];
/** Extract unique host addresses from ~/.ssh/known_hosts (first field, comma lists, [host]:port). */
export declare function parseKnownHosts(text: string): DiscoveredHost[];
/** Which private keys exist locally (informational hint only). */
export declare function localKeys(): string[];
/** Full discovery: ssh config entries first (richer), then known_hosts-only addresses. */
export declare function discoverHosts(): {
    hosts: DiscoveredHost[];
    keys: string[];
    sshDir: string;
};
