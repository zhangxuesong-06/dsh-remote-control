export interface SshTarget {
    id: string;
    host: string;
    port?: number;
    /** Login user on the target. */
    username: string;
    /** Private key path; defaults to the plugin-managed key. */
    identityFile?: string;
    /** Optional dedicated known_hosts file (kept out of the user's ~/.ssh to avoid write contention). */
    knownHostsFile?: string;
}
/** Plugin-private known_hosts path derived from the identity file's directory. */
export declare function defaultKnownHostsFile(identityFile: string): string;
export interface SshRunResult {
    code: number;
    stdout: string;
    stderr: string;
    timedOut: boolean;
}
/** Directory that holds the plugin's SSH identity (inside the registry dir). */
export declare function sshKeyDir(registryPath: string): string;
export declare function defaultIdentityFile(registryPath: string): string;
/**
 * Ensure a dedicated ed25519 key exists; return {privatePath, publicKey}.
 * Never overwrites an existing key. Async because the harness sandbox blocks
 * synchronous child-process spawn (EPERM); it allows execFile.
 */
export declare function ensureIdentity(registryPath: string): Promise<{
    privatePath: string;
    publicKey: string;
    created: boolean;
}>;
/** Run a command on the target over SSH. `argv` is passed verbatim (no shell on our side). */
export declare function sshRun(target: SshTarget, identityFile: string, argv: string[], options?: {
    timeoutMs?: number;
    cwd?: string;
    env?: Record<string, string>;
    stdin?: Buffer;
}): Promise<SshRunResult>;
/** Execute a shell command *string* on the target via its login shell (used by exec tool). */
export declare function sshShell(target: SshTarget, identityFile: string, command: string, options?: {
    timeoutMs?: number;
    cwd?: string;
    env?: Record<string, string>;
}): Promise<SshRunResult>;
/** Copy a local file to the target via scp. */
export declare function scpUpload(target: SshTarget, identityFile: string, localPath: string, remotePath: string, timeoutMs?: number): Promise<SshRunResult>;
/** Download a remote file via scp. */
export declare function scpDownload(target: SshTarget, identityFile: string, remotePath: string, localPath: string, timeoutMs?: number): Promise<SshRunResult>;
/**
 * The ONE command a user pastes in the target's terminal. It does everything needed:
 * enable/start the SSH server (if not already), and authorize this plugin's key.
 * Three platforms; the UI shows exactly one, chosen by the user.
 */
export declare function publicKeyInstallCommand(publicKey: string): {
    linux: string;
    macos: string;
    windows: string;
};
/**
 * Connectivity probe AND write-verification in one step: authenticate, then create
 * ~/.dsh-remote-agent/connection-ok.txt on the target. Writing a file proves the
 * session can actually run commands and touch the filesystem (not just handshake).
 * Returns the file path + timestamp so the UI can show concrete evidence.
 */
export declare function sshProbe(target: SshTarget, identityFile: string, timeoutMs?: number, options?: {
    verifyWrite?: boolean;
}): Promise<{
    ok: boolean;
    detail: string;
    verifyFile?: string;
    verifyTime?: string;
    command?: string;
}>;
