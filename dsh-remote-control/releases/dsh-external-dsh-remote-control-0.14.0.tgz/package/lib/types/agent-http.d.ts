import type { RemoteMachine } from "./registry.js";
export declare class RemoteAgentError extends Error {
    readonly code: string;
    readonly status: number;
    constructor(message: string, code?: string, status?: number);
}
export interface ExecResult {
    command: string;
    exitCode: number | null;
    signal: string | null;
    stdout: string;
    stderr: string;
    durationMs: number;
    timedOut: boolean;
    truncated: boolean;
}
export interface SysInfo {
    hostname: string;
    platform: string;
    osType: string;
    arch: string;
    release: string;
    uptimeSec: number;
    loadAvg: number[];
    cpus: {
        model: string;
        count: number;
    };
    memTotalBytes: number;
    memFreeBytes: number;
    user: string;
    homedir: string;
    nodeVersion: string;
    agentVersion: string;
    agentName: string;
}
export interface ProcessInfo {
    pid: number;
    ppid?: number;
    name: string;
    cmd?: string;
}
/** Background job started through /job/start (long commands that outlive a request). */
export interface JobInfo {
    id: string;
    command: string;
    cwd: string | null;
    running: boolean;
    startedAt: number;
    endedAt: number | null;
    exitCode: number | null;
    signal: string | null;
    timedOut: boolean;
    durationMs: number;
    stdoutBytes: number;
    stderrBytes: number;
    truncated: boolean;
}
/** Job metadata plus the output captured so far. */
export interface JobOutput extends JobInfo {
    stdout: string;
    stderr: string;
}
export interface FsEntry {
    name: string;
    type: "file" | "directory" | "other";
    sizeBytes: number;
    mtimeMs: number;
}
export interface FsStat {
    path: string;
    exists: boolean;
    type?: "file" | "directory" | "other";
    sizeBytes?: number;
    mtimeMs?: number;
    birthtimeMs?: number;
    mode?: number;
}
export interface FsReadResult {
    path: string;
    encoding: "utf8" | "base64";
    sizeBytes: number;
    content: string;
    truncated: boolean;
}
export interface FsWriteResult {
    path: string;
    sizeBytes: number;
    op: string;
}
export interface HealthInfo {
    ok: boolean;
    name: string;
    version: string;
    hostname: string;
    platform: string;
    uptimeSec: number;
    time: string;
    workspace?: string | null;
    runningJobs?: number;
    keepAwake?: boolean;
}
export interface ExecOptions {
    cwd?: string;
    env?: Record<string, string>;
    timeoutMs?: number;
}
export interface TransferOptions {
    timeoutMs?: number;
}
/**
 * Conservative synchronous timeout for public tunnels. Provider/plan limits vary.
 * Prefer a structured agent timeout over an ambiguous edge timeout.
 */
export declare const TUNNEL_EXEC_TIMEOUT_MS = 90000;
/** Conservative upload threshold; actual provider/plan limits vary. */
export declare const TUNNEL_UPLOAD_LIMIT_BYTES: number;
declare function machineLabel(machine: RemoteMachine): string;
/** Client for one remote agent. All methods throw RemoteAgentError. */
export declare class RemoteClient {
    readonly machine: RemoteMachine;
    readonly defaultTimeoutMs: number;
    constructor(machine: RemoteMachine, defaultTimeoutMs?: number);
    /** Keep the deadline alive until the response body has been consumed/written. */
    private fetchVia;
    private retryable;
    /** JSON request with per-path fallback (connection errors only). */
    request<T>(method: string, pathname: string, body?: unknown, timeoutMs?: number): Promise<T>;
    health(timeoutMs?: number): Promise<HealthInfo>;
    sysinfo(timeoutMs?: number): Promise<SysInfo>;
    exec(command: string, options?: ExecOptions): Promise<ExecResult>;
    /** Public tunnels cap one HTTP exchange at ~100s, so the agent timeout stays below it. */
    effectiveExecTimeout(requested?: number): number;
    fs(op: string, payload: Record<string, unknown>, timeoutMs?: number): Promise<unknown>;
    /** Upload a local file to the remote machine as raw octets. */
    upload(localPath: string, remotePath: string, options?: TransferOptions): Promise<FsWriteResult>;
    /** Download a remote file into a local path (created atomically). */
    download(remotePath: string, localPath: string, options?: TransferOptions): Promise<{
        localPath: string;
        sizeBytes: number;
    }>;
    processes(timeoutMs?: number): Promise<ProcessInfo[]>;
    killProcess(pid: number, timeoutMs?: number): Promise<{
        pid: number;
        killed: boolean;
        message: string;
    }>;
    /** Start a long-running command in the background; returns immediately with a job id. */
    startJob(command: string, options?: ExecOptions): Promise<JobInfo>;
    listJobs(timeoutMs?: number): Promise<JobInfo[]>;
    jobOutput(id: string, timeoutMs?: number): Promise<JobOutput>;
    killJob(id: string, timeoutMs?: number): Promise<{
        id: string;
        killed: boolean;
        message: string;
    }>;
}
export { machineLabel };
