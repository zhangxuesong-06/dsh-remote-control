import type { RemoteMachine, RemotePath } from "./registry.js";
export interface ReverseSessionStatus {
    machineId: string;
    agentPort: number;
    proxyPort: number;
    idleCount: number;
    busyCount: number;
    lastSeen: number;
    connected: boolean;
}
export interface ReverseGatewayOptions {
    listenHost: string;
    listenPort: number;
    proxyStart: number;
    proxyCount: number;
    /** 空闲隧道 PING 间隔（默认 30s；测试可调小）。 */
    heartbeatIntervalMs?: number;
    /** 超过该时长未收到 PONG 判定死链（默认 75s）。 */
    staleIdleMs?: number;
    /** 短命令引导时按需下发的 agent 脚本路径。 */
    agentFilePath: string;
    /** Resolve the machine entry owning a handshake token (plaintext or sha256). */
    findMachineByToken: (token: string) => RemoteMachine | undefined;
    /** Persist the reverse path + assigned proxy port for a machine. */
    onPathsUpdate: (machineId: string, paths: RemotePath[], reversePort: number) => void;
    log: (message: string) => void;
}
export declare class ReverseGateway {
    private readonly opts;
    private server;
    private readonly proxies;
    private readonly proxyToSession;
    private readonly sessions;
    private readonly queues;
    private readonly proxyClients;
    private readonly idleListeners;
    private readonly lastPong;
    private heartbeat;
    private nextProxyPort;
    constructor(opts: ReverseGatewayOptions);
    actualListenPort(): number;
    isRunning(): boolean;
    /** Bind the reverse listener (idempotent; EADDRINUSE 时自动顺延最多 20 个端口)。 */
    start(): Promise<number>;
    /** Ensure a local proxy port exists for one machine (idempotent). */
    ensureProxy(machine: RemoteMachine, agentPort: number): Promise<number>;
    status(): ReverseSessionStatus[];
    stop(): Promise<void>;
    private assignProxyPort;
    private handleReverseConn;
    private finishHandshake;
    private ensureProxyServer;
    private handleProxyClient;
    private pair;
    /** 新隧道到达时，立即满足正在排队的代理客户端。 */
    private drainQueue;
    /** 周期 PING：空闲隧道无 PONG 超过阈值即判定死链，断开让 agent 自动重连。 */
    private heartbeatTick;
}
