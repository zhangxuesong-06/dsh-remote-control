import type { RemoteMachine } from "./registry.js";
export declare function isRemoteAbsolute(value: string): boolean;
export declare function executionDefaults(machine: RemoteMachine, cwd?: string, env?: Record<string, string>): {
    cwd: string;
    env: {
        [x: string]: string;
    };
};
export declare function validateDefaultEnv(raw: unknown): Record<string, string>;
