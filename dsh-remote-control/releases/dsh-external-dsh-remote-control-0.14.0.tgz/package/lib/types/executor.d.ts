/**
 * Unified execution backend: the same operations over either transport.
 *
 * - 'ssh'   : no agent required. Runs commands/reads files through the target's
 *             own OpenSSH server (key auth). This is the default when no agent
 *             is installed.
 * - 'agent' : the optional HTTP agent (faster, background jobs).
 *
 * Tool handlers call this interface instead of RemoteClient directly, so a
 * machine works the moment it is reachable over SSH, with no agent present.
 */
import { type ExecResult, type SysInfo, type HealthInfo } from "./agent-http.js";
import type { RemoteMachine } from "./registry.js";
import { type SshTarget } from "./ssh.js";
export interface ExecOptions {
    cwd?: string;
    env?: Record<string, string>;
    timeoutMs?: number;
}
export interface Executor {
    readonly machine: RemoteMachine;
    readonly transport: "ssh" | "agent";
    health(timeoutMs?: number): Promise<HealthInfo>;
    exec(command: string, options?: ExecOptions): Promise<ExecResult>;
    fs(op: string, payload: Record<string, unknown>): Promise<unknown>;
    upload(localPath: string, remotePath: string): Promise<{
        sizeBytes: number;
        localPath?: string;
    }>;
    download(remotePath: string, localPath: string): Promise<{
        sizeBytes: number;
        localPath?: string;
    }>;
    sysinfo(): Promise<SysInfo>;
    processes(): Promise<Array<{
        pid: number;
        name: string;
        cmd?: string;
    }>>;
    killProcess(pid: number): Promise<{
        pid: number;
        killed: boolean;
        message: string;
    }>;
    /** Agent-only: background jobs. Undefined on SSH transport. */
    startJob?(command: string, options?: ExecOptions): Promise<import("./agent-http.js").JobInfo>;
    listJobs?(): Promise<import("./agent-http.js").JobInfo[]>;
    jobOutput?(id: string): Promise<import("./agent-http.js").JobOutput>;
    killJob?(id: string): Promise<{
        id: string;
        killed: boolean;
        message: string;
    }>;
}
/** True when the machine should be driven over SSH (no agent available). */
export declare function usesSsh(machine: RemoteMachine): boolean;
export declare function sshTargetOf(machine: RemoteMachine, identityFile: string): SshTarget & {
    identityFile: string;
};
/** SSH-backed executor: interprets fs ops with POSIX tools on the target. */
export declare class SshExecutor implements Executor {
    readonly machine: RemoteMachine;
    private identityFile;
    private defaultTimeoutMs;
    readonly transport: "ssh";
    constructor(machine: RemoteMachine, identityFile: string, defaultTimeoutMs?: number);
    private target;
    private run;
    health(timeoutMs?: number): Promise<HealthInfo>;
    exec(command: string, options?: ExecOptions): Promise<ExecResult>;
    fs(op: string, payload: Record<string, unknown>): Promise<unknown>;
    upload(localPath: string, remotePath: string): Promise<{
        sizeBytes: number;
    }>;
    download(remotePath: string, localPath: string): Promise<{
        sizeBytes: number;
    }>;
    sysinfo(): Promise<SysInfo>;
    processes(): Promise<Array<{
        pid: number;
        name: string;
        cmd?: string;
    }>>;
    killProcess(pid: number): Promise<{
        pid: number;
        killed: boolean;
        message: string;
    }>;
}
/** Agent-backed executor (wraps the existing RemoteClient). */
export declare class AgentExecutor implements Executor {
    readonly machine: RemoteMachine;
    readonly transport: "agent";
    private client;
    constructor(machine: RemoteMachine, defaultTimeoutMs?: number);
    health(timeoutMs?: number): Promise<HealthInfo>;
    exec(command: string, options?: ExecOptions): Promise<ExecResult>;
    fs(op: string, payload: Record<string, unknown>): Promise<unknown>;
    upload(localPath: string, remotePath: string): Promise<import("./agent-http.js").FsWriteResult>;
    download(remotePath: string, localPath: string): Promise<{
        localPath: string;
        sizeBytes: number;
    }>;
    sysinfo(): Promise<SysInfo>;
    processes(): Promise<import("./agent-http.js").ProcessInfo[]>;
    killProcess(pid: number): Promise<{
        pid: number;
        killed: boolean;
        message: string;
    }>;
    startJob(command: string, options?: ExecOptions): Promise<import("./agent-http.js").JobInfo>;
    listJobs(): Promise<import("./agent-http.js").JobInfo[]>;
    jobOutput(id: string): Promise<import("./agent-http.js").JobOutput>;
    killJob(id: string): Promise<{
        id: string;
        killed: boolean;
        message: string;
    }>;
}
