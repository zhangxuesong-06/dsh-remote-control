/** One connection path to a machine (direct, reverse tunnel or public tunnel). */
export interface RemotePath {
    kind: "direct" | "reverse" | "tunnel";
    host: string;
    port: number;
    /** Absolute base URL for public-tunnel paths, e.g. https://xxx.trycloudflare.com */
    url?: string;
}
/** One remote machine entry. */
export interface RemoteMachine {
    /** Stable id used as the `machine` argument of every tool. */
    id: string;
    /** Human-readable label. */
    name: string;
    /** IP or hostname of the target computer. */
    host: string;
    /** Agent port (default 5188) — used only when an agent is present. */
    port: number;
    /** Shared secret; must match the agent's --token (agent mode only). */
    token: string;
    /** Optional SHA-256 of the token when the plaintext is not stored. */
    tokenSha256?: string;
    /** Disabled machines are skipped by probes and reject operations. */
    enabled: boolean;
    /** Remote workspace directory: relative exec/fs/upload/download paths resolve here. */
    workspace?: string;
    /** SSH port (default 22). */
    sshPort?: number;
    /** Preferred transport: 'ssh' = target's SSH port直接可达; 'tunnel' = 经公网中继（如 Cloudflare Tunnel
     *  暴露目标机 SSH）; 'agent' = HTTP 代理。 */
    transport?: "ssh" | "agent" | "tunnel";
    /** transport === 'tunnel' 时，公网中继主机（域名/IP），其端口转发到目标机 SSH。 */
    tunnelHost?: string;
    /** transport === 'tunnel' 时，公网中继端口（默认 22）。 */
    tunnelPort?: number;
    /** transport === 'tunnel' 时，要转发的 Cloudflare 域名（如 ssh.example.com）。
     *  设置后由插件托管 `cloudflared access tcp`，tunnelHost/tunnelPort 指向本地转发端口。 */
    tunnelForwardHost?: string;
    /** Optional per-machine SSH private key path; defaults to the plugin-managed key. */
    sshIdentityFile?: string;
    /** Remote OS platform, learned from /health (win32/linux/darwin). */
    platform?: "win32" | "linux" | "darwin" | string;
    /** Ordered connection paths; first live path wins (client falls back). */
    paths?: RemotePath[];
    /** Optional public tunnel base URL (Cloudflare / ngrok / frp), e.g. https://xxx.trycloudflare.com. */
    tunnelUrl?: string;
    /** Local proxy port assigned to the reverse tunnel, when active. */
    reversePort?: number;
    /** When the token was created (ms epoch); helps reconcile stale deploy commands. */
    tokenCreatedAt?: number;
    /** Saved from the settings panel: target login account (optional). */
    username?: string;
    /** Saved from the settings panel: target login password (plaintext, file mode 0600; never returned by API). */
    password?: string;
    /** Target OS hint saved from the panel (auto/windows/linux). */
    osHint?: "auto" | "windows" | "linux";
    /** Local workspace folder on this controller machine for this machine combo. */
    localWorkspace?: string;
    /** Probe on startup; this never deploys or executes commands. */
    autoConnect?: boolean;
    defaultCwd?: string;
    /** Ordinary defaults only: do not store credentials here. */
    defaultEnv?: Record<string, string>;
    lastSeenAt?: number;
    lastAgentVersion?: string;
    lastHostname?: string;
}
export interface MachineRegistry {
    version: 1;
    machines: RemoteMachine[];
    /** Execution mode chosen in the UI: 'local' (default) or 'remote'. */
    mode?: "local" | "remote";
    /** Machine the UI/composer indicator treats as current (only meaningful when mode === 'remote'). */
    activeMachineId?: string;
}
export declare const defaultRegistryPath: string;
/**
 * Normalize a public-tunnel address into an absolute base URL (no trailing slash).
 * Bare hosts are assumed to be HTTPS (Cloudflare/ngrok style). Returns undefined
 * for empty or non-http(s) values so a bad value never breaks loading.
 */
export declare function normalizeTunnelUrl(raw?: string): string | undefined;
/** Normalize one raw machine record with tolerant defaults. */
export declare function normalizeMachine(raw: unknown): RemoteMachine | null;
/**
 * Load the registry. Malformed files never crash the plugin: a parse error
 * yields an empty registry (the error is reported through the thrown-away
 * diagnostics path by the caller).
 */
export declare function loadRegistry(file?: string): MachineRegistry;
/** Atomically save the registry (tmp file + rename) and restrict permissions. */
export declare function saveRegistry(file: string | undefined, registry: MachineRegistry): void;
/**
 * Resolve the effective registry path from config.
 *
 * Order: explicit config → DSH_HOME/dsh-remote-control/machines.json →
 * ~/.dsh-remote-control/machines.json.
 *
 * IMPORTANT: the GUI process does not always inherit DSH_HOME (it can be
 * launched from a different shell), so the same plugin could otherwise read
 * two different files depending on how it was started. To keep every entry
 * point on ONE file, when DSH_HOME is absent we also probe the conventional
 * harness data locations and reuse whichever already has data — so machines
 * saved through one route never appear "lost" through another.
 */
export declare function resolveRegistryPath(configured: string): string;
