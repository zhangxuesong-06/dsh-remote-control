import type { Context } from "cordis";
import z from "schemastery";
export declare const name = "dsh-remote-control";
export declare const inject: string[];
export declare const Config: z<Schemastery.ObjectS<{
    /** 机器登记表路径；默认 DSH_HOME/dsh-remote-control/machines.json */
    registryFile: z<string, string>;
    /** 远程调用默认超时（毫秒）。 */
    defaultTimeoutMs: z<number, number>;
    /** remote_machine_list 在线探测默认超时（毫秒）。 */
    healthProbeTimeoutMs: z<number, number>;
    /** 反向隧道网关监听地址（目标机能访问到的本机地址）。 */
    reverseListenHost: z<string, string>;
    /** 反向隧道网关监听端口（目标机回连这里）。 */
    reverseListenPort: z<number, number>;
    /** 本地代理端口段起始。 */
    reverseProxyStart: z<number, number>;
    /** 本地代理端口段长度。 */
    reverseProxyCount: z<number, number>;
}>, Schemastery.ObjectT<{
    /** 机器登记表路径；默认 DSH_HOME/dsh-remote-control/machines.json */
    registryFile: z<string, string>;
    /** 远程调用默认超时（毫秒）。 */
    defaultTimeoutMs: z<number, number>;
    /** remote_machine_list 在线探测默认超时（毫秒）。 */
    healthProbeTimeoutMs: z<number, number>;
    /** 反向隧道网关监听地址（目标机能访问到的本机地址）。 */
    reverseListenHost: z<string, string>;
    /** 反向隧道网关监听端口（目标机回连这里）。 */
    reverseListenPort: z<number, number>;
    /** 本地代理端口段起始。 */
    reverseProxyStart: z<number, number>;
    /** 本地代理端口段长度。 */
    reverseProxyCount: z<number, number>;
}>>;
export interface Config {
    registryFile: string;
    defaultTimeoutMs: number;
    healthProbeTimeoutMs: number;
    reverseListenHost: string;
    reverseListenPort: number;
    reverseProxyStart: number;
    reverseProxyCount: number;
}
/**
 * Boot-safe 入口：任何异常都只降级（打印日志），绝不向 loader 抛出，
 * 保证插件自身问题永远不会阻断 harness 启动。
 */
export declare function apply(ctx: Context, rawConfig: Config): void;
